MY MONEY MANAGER PWA (Android)

Files:
- index.html: app
- manifest.json: install metadata
- sw.js: offline cache
- icon.svg: app icon

IMPORTANT:
A PWA must be hosted over HTTPS (or localhost) to install and use its service worker/offline mode.
This ZIP is a complete PWA source bundle, not a direct APK.

Quick deploy:
1. Upload these files to an HTTPS static host (GitHub Pages, Netlify, Cloudflare Pages, etc.).
2. Open the deployed URL in Chrome on Android.
3. Menu > Install app / Add to Home screen.
4. Use Settings > Backup JSON regularly; records are stored locally on that browser/device.

Data is local only. No cloud sync/login yet. Keep backups before clearing browser storage.
